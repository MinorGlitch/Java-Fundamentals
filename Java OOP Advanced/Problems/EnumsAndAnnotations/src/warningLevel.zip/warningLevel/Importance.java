package warningLevel;

public enum Importance {
    LOW, NORMAL, MEDIUM, HIGH
}
