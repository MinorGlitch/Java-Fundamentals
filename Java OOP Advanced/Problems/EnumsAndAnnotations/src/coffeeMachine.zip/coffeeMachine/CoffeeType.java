package coffeeMachine;

public enum CoffeeType {
    ESPRESSO, LATTE, IRISH
}
