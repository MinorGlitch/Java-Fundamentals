package coffeeMachine;

public class Main {
}
