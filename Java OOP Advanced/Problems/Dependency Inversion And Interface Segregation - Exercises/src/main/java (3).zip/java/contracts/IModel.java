package contracts;

public interface IModel {
    String getModel();
}
