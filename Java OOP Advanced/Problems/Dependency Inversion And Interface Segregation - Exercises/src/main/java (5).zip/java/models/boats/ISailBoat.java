package models.boats;

public interface ISailBoat extends IBoat {
    int getSailEfficiency();
}
