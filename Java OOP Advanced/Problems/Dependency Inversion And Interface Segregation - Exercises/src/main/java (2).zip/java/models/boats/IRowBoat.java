package models.boats;

public interface IRowBoat extends IBoat {
    int getOars();
}
