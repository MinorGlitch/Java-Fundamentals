package infernoInfinity;

import java.util.*;

public class WeaponRepository {
    private Map<String, Weapon> weapons;

    public WeaponRepository() {
        this.weapons = new HashMap<>();
    }

    public Map<String, Weapon> getWeapons() {
        return weapons;
    }
}
