package cars;

public enum CarType {
    PERFORMANCE,
    SHOW;
}
