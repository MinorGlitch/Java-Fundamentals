package races;

public enum RaceType {
    CASUAL,
    DRIFT,
    DRAG;
}
