package mordorsCrueltyPlan.foods;

public class Food {
    private int happiness;

    public Food(int happiness) {
        this.happiness = happiness;
    }

    public int getHappiness() {
        return this.happiness;
    }
}
