package mordorsCrueltyPlan.foods;

public class Mushrooms extends Food {
    public Mushrooms() {
        super(-10);
    }
}
