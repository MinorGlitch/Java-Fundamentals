package mordorsCrueltyPlan.foods;

public class Apple extends Food {
    public Apple() {
        super(1);
    }
}
