package mordorsCrueltyPlan.foods;

public class HoneyCake extends Food {
    public HoneyCake() {
        super(5);
    }
}
