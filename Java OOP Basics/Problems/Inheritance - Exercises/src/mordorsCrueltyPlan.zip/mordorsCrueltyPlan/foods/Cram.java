package mordorsCrueltyPlan.foods;

public class Cram extends Food {
    public Cram() {
        super(2);
    }
}
