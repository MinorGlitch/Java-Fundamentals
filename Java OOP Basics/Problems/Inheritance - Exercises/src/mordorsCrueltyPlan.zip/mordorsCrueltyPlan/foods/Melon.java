package mordorsCrueltyPlan.foods;

public class Melon extends Food {
    public Melon() {
        super(1);
    }
}
