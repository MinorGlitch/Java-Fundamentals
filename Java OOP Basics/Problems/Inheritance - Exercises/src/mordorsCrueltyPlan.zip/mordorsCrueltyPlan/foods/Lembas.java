package mordorsCrueltyPlan.foods;

public class Lembas extends Food {
    public Lembas() {
        super(3);
    }
}
